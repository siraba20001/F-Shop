// -------------------------
// Gestion du Panier
// -------------------------

let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Met à jour le compteur dans le header
function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  document.getElementById("cart-count").textContent = count;
}

// Sauvegarde dans localStorage
function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}

// Ajouter au panier
function addToCart(name, price, size, image) {
  const existing = cart.find(item => item.name === name && item.size === size);
  if (existing) {
    existing.quantity++;
  } else {
    cart.push({ name, price, size, image, quantity: 1 });
  }
  saveCart();
  alert(`${name} (${size}) a été ajouté au panier !`);
}

// Affiche les articles du panier sur Panier.html
function renderCart() {
  const cartItems = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");

  if (!cartItems) return; // on est sur produits.html, pas besoin d'afficher

  cartItems.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const row = document.createElement("tr");
    row.innerHTML = `
      <td><img src="${item.image}" width="60"/> <br>${item.name}</td>
      <td>${item.size}</td>
      <td>${item.price.toLocaleString()} CFA</td>
      <td>
        <button class="qty-btn" onclick="changeQty(${index}, -1)">-</button>
        ${item.quantity}
        <button class="qty-btn" onclick="changeQty(${index}, 1)">+</button>
      </td>
      <td>${itemTotal.toLocaleString()} CFA</td>
      <td><button onclick="removeItem(${index})">Supprimer</button></td>
    `;
    cartItems.appendChild(row);
  });

  cartTotal.textContent = total.toLocaleString() + " CFA";
}

// Modifier quantité
function changeQty(index, delta) {
  cart[index].quantity += delta;
  if (cart[index].quantity <= 0) cart.splice(index, 1);
  saveCart();
  renderCart();
}

// Supprimer un article
function removeItem(index) {
  cart.splice(index, 1);
  saveCart();
  renderCart();
}

// Vider le panier
document.getElementById("clear-cart")?.addEventListener("click", () => {
  cart = [];
  saveCart();
  renderCart();
});

// -------------------------
// Ajouter aux boutons produits (fixes + dynamiques)
// -------------------------
document.querySelectorAll(".add-to-cart").forEach((btn) => {
  btn.addEventListener("click", () => {
    const product = btn.closest(".product");
    const name = product.querySelector("h3").textContent;
    const price = parseInt(product.querySelector(".price").textContent.replace(/\s|CFA/g, ""));
    const size = product.querySelector(".taille-select")?.value || "Standard";
    const image = product.querySelector("img").src;
    addToCart(name, price, size, image);
  });
});

// Initialisation
updateCartCount();
renderCart();
// -------------------------
// Envoi de la commande via WhatsApp
// -------------------------
document.getElementById("checkout")?.addEventListener("click", () => {
  if (cart.length === 0) {
    alert("Votre panier est vide !");
    return;
  }

  let message = "🛒 Nouvelle commande F-Shop :\n\n";

  cart.forEach((item) => {
    message += `- ${item.name} (${item.size}) x${item.quantity} = ${formatPrice(item.price * item.quantity)}\n`;
  });

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  message += `\n💰 Total : ${formatPrice(total)}`;

  // Remplace le numéro ci-dessous par ton numéro WhatsApp avec indicatif
  const phoneNumber = "22374743770"; 
  const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  window.open(url, "_blank");
});
