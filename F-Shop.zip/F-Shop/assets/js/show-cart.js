document.addEventListener("DOMContentLoaded", () => {
  const cartItemsContainer = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  const clearCartBtn = document.getElementById("clear-cart");
  const orderBtn = document.getElementById("order-btn");

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  function saveCart() {
    localStorage.setItem("cart", JSON.stringify(cart));
  }

  function renderCart() {
    cartItemsContainer.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td><img src="${item.img}" width="50"> ${item.name}</td>
        <td>${item.taille}</td>
        <td>
          <button class="qty-btn decrease" data-index="${index}">-</button>
          ${item.qty}
          <button class="qty-btn increase" data-index="${index}">+</button>
        </td>
        <td>${item.price} CFA</td>
        <td>${item.price * item.qty} CFA</td>
        <td><button class="remove" data-index="${index}">❌</button></td>
      `;

      total += item.price * item.qty;
      cartItemsContainer.appendChild(row);
    });

    cartTotal.textContent = total;
  }

  // Modifier quantité
  cartItemsContainer.addEventListener("click", e => {
    const index = e.target.dataset.index;

    if (e.target.classList.contains("increase")) {
      cart[index].qty++;
      saveCart();
      renderCart();
    }

    if (e.target.classList.contains("decrease")) {
      if (cart[index].qty > 1) {
        cart[index].qty--;
      } else {
        cart.splice(index, 1);
      }
      saveCart();
      renderCart();
    }

    if (e.target.classList.contains("remove")) {
      cart.splice(index, 1);
      saveCart();
      renderCart();
    }
  });

  // Vider panier
  clearCartBtn.addEventListener("click", () => {
    cart = [];
    saveCart();
    renderCart();
  });

  // Commander via WhatsApp
  orderBtn.addEventListener("click", () => {
    if (cart.length === 0) {
      alert("Votre panier est vide !");
      return;
    }

    let message = "🛒 Nouvelle commande F-Shop :\n\n";
    cart.forEach(item => {
      message += `- ${item.name} (${item.taille}) x${item.qty} = ${item.price * item.qty} CFA\n`;
    });
    message += `\n💰 TOTAL : ${cart.reduce((sum, i) => sum + i.price * i.qty, 0)} CFA\n\n`;
    message += "📞 Merci de confirmer votre commande.";

    const phone = "22374743770"; // ton numéro WhatsApp
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  });

  renderCart();
});
