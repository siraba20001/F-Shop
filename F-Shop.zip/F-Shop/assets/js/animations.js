// -------------------------
// Animations au scroll
// -------------------------

document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll("section, .product, .about-item, .feature, .testimonial");

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("fade-in");
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1
  });

  elements.forEach(el => observer.observe(el));
});