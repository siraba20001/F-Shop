// -------------------------
// SLIDER avec effet fondu
// -------------------------
document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".slide");
  const prevBtn = document.querySelector(".prev");
  const nextBtn = document.querySelector(".next");
  const dotsContainer = document.querySelector(".dots");

  let index = 0;
  let timer;

  // Créer les dots automatiquement
  slides.forEach((_, i) => {
    const dot = document.createElement("span");
    dot.classList.add("dot");
    if (i === 0) dot.classList.add("active");
    dot.addEventListener("click", () => {
      index = i;
      showSlide(index);
      resetTimer();
    });
    dotsContainer.appendChild(dot);
  });

  const dots = document.querySelectorAll(".dot");

  function showSlide(i) {
    slides.forEach((slide, idx) => {
      slide.classList.toggle("active", idx === i);
    });
    dots.forEach((dot, idx) => {
      dot.classList.toggle("active", idx === i);
    });
  }

  function nextSlide() {
    index = (index + 1) % slides.length;
    showSlide(index);
  }

  function prevSlide() {
    index = (index - 1 + slides.length) % slides.length;
    showSlide(index);
  }

  function resetTimer() {
    clearInterval(timer);
    timer = setInterval(nextSlide, 5000);
  }

  prevBtn.addEventListener("click", () => {
    prevSlide();
    resetTimer();
  });

  nextBtn.addEventListener("click", () => {
    nextSlide();
    resetTimer();
  });

  // Démarre l’auto slide
  timer = setInterval(nextSlide, 5000);
});
  // =============================================
  // PANIER (localStorage)
  // =============================================
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  function saveCart() {
    localStorage.setItem("cart", JSON.stringify(cart));
  }

  // Boutons "Ajouter au panier"
  document.querySelectorAll(".add-to-cart").forEach(button => {
    button.addEventListener("click", () => {
      const name = button.getAttribute("data-name");
      const price = parseInt(button.getAttribute("data-price"));

      const existing = cart.find(item => item.name === name);
      if (existing) {
        existing.quantity++;
      } else {
        cart.push({
          name,
          price,
          quantity: 1,
          size: "M" // taille par défaut
        });
      }

      saveCart();
      alert(name + " ajouté au panier !");
    });
  });

  // Affichage du panier dans cart.html
  displayCart();

  function displayCart() {
    const cartTable = document.getElementById("cart-items");
    const totalContainer = document.getElementById("cart-total");

    if (!cartTable) return;

    cartTable.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${item.name}</td>
        <td>
          <select onchange="updateSize(${index}, this.value)">
            <option ${item.size === "S" ? "selected" : ""}>S</option>
            <option ${item.size === "M" ? "selected" : ""}>M</option>
            <option ${item.size === "L" ? "selected" : ""}>L</option>
            <option ${item.size === "XL" ? "selected" : ""}>XL</option>
            <option ${item.size === "XXL" ? "selected" : ""}>XXL</option>
          </select>
        </td>
        <td>
          <input type="number" min="1" value="${item.quantity}" onchange="updateQuantity(${index}, this.value)">
        </td>
        <td>${item.price} CFA</td>
        <td>${item.price * item.quantity} CFA</td>
        <td><button onclick="removeItem(${index})">❌</button></td>
      `;

      cartTable.appendChild(row);
      total += item.price * item.quantity;
    });

    totalContainer.innerText = total + " CFA";
  }

  // rendre ces fonctions globales pour qu'elles soient accessibles
  window.updateQuantity = (index, value) => {
    cart[index].quantity = parseInt(value);
    saveCart();
    displayCart();
  };

  window.updateSize = (index, value) => {
    cart[index].size = value;
    saveCart();
  };

  window.removeItem = (index) => {
    cart.splice(index, 1);
    saveCart();
    displayCart();
  };

  // =============================================
  // FILTRES + RECHERCHE PRODUITS (produits.html)
  // =============================================
  const productsContainer = document.getElementById("products-container");
  if (productsContainer) {
    const filterPrice = document.getElementById("filter-price");
    const filterSize = document.getElementById("filter-size");
    const searchInput = document.getElementById("search-product");
    let products = Array.from(productsContainer.querySelectorAll(".product"));

    function renderProducts(list) {
      productsContainer.innerHTML = "";
      list.forEach(p => productsContainer.appendChild(p));
    }

    function applyFilters() {
      let filtered = [...products];

      // Taille
      const size = filterSize.value;
      if (size !== "all") {
        filtered = filtered.filter(p => p.getAttribute("data-size") === size);
      }

      // Prix
      const price = filterPrice.value;
      if (price === "asc") {
        filtered.sort((a, b) => parseInt(a.dataset.price) - parseInt(b.dataset.price));
      } else if (price === "desc") {
        filtered.sort((a, b) => parseInt(b.dataset.price) - parseInt(a.dataset.price));
      }

      // Recherche
      const searchText = searchInput.value.toLowerCase();
      if (searchText.trim() !== "") {
        filtered = filtered.filter(p =>
          p.querySelector("h3").innerText.toLowerCase().includes(searchText)
        );
      }

      renderProducts(filtered);
    }

    filterPrice.addEventListener("change", applyFilters);
    filterSize.addEventListener("change", applyFilters);
    searchInput.addEventListener("input", applyFilters);
  }