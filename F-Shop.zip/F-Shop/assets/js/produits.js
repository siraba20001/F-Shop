document.addEventListener("DOMContentLoaded", () => {
  const addToCartButtons = document.querySelectorAll(".add-to-cart");

  // Fonction pour mettre à jour le badge du panier
  function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    const cartCountEl = document.getElementById("cart-count");

    if (cartCountEl) {
      cartCountEl.textContent = count;
    }
  }

  // Événement : ajouter au panier
  addToCartButtons.forEach((btn, index) => {
    btn.addEventListener("click", () => {
      const productCard = btn.closest(".product");
      const name = productCard.querySelector("h3").textContent;
      const price = parseInt(productCard.querySelector(".price").textContent);
      const img = productCard.querySelector("img").src;
      const taille = productCard.querySelector("select").value;

      let cart = JSON.parse(localStorage.getItem("cart")) || [];

      // Vérifier si le produit avec cette taille existe déjà
      let existing = cart.find(item => item.name === name && item.taille === taille);
      if (existing) {
        existing.qty++;
      } else {
        cart.push({ name, price, img, taille, qty: 1 });
      }

      localStorage.setItem("cart", JSON.stringify(cart));
      updateCartCount(); // ✅ Met à jour le badge
      alert(`${name} (${taille}) ajouté au panier !`);
    });
  });

  // ✅ Met à jour le badge dès l’ouverture de la page
  updateCartCount();
});
